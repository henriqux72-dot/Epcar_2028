# EPCAR 2028 — GitHub Pages

## Publicar pelo GitHub

1. Crie um repositório no GitHub (por exemplo: `epcar-2028`).
2. Envie TODOS os arquivos desta pasta para a raiz do repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde o GitHub Pages publicar.
7. O GitHub mostrará o endereço público do site.

## Instalar no Android

Abra o endereço publicado no Chrome. Depois, use o menu do Chrome e escolha
**Adicionar à tela inicial** ou **Instalar aplicativo**, quando essa opção aparecer.

O service worker permite que os arquivos do aplicativo sejam armazenados em cache
para uso offline após o primeiro acesso.
